export interface CreateMajorData {
  name: string;
  description: string;
  code: string;
}

export interface UpdateMajorData {
  name: string;
  description: string;
  code: string;
}